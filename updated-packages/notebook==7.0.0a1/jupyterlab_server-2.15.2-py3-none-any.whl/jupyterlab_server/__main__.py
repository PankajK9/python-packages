import sys

from jupyterlab_server.app import main

sys.exit(main())
