from .otBase import BaseTTXConverter


class table_T_S_I_C_(BaseTTXConverter):
    pass
