# Master version for Pillow
__version__ = "9.2.0"
