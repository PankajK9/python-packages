from .nbconvertapp import main

main()
