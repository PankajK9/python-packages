import logging

logger = logging.getLogger(__name__)


class MetaPandasDataset:
    def column_map_expectation(self) -> None:
        logger.debugv("MetaPandasDataset.column_map_expectation")
