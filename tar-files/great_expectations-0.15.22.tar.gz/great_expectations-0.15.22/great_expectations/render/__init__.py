from .view import DefaultJinjaPageView
