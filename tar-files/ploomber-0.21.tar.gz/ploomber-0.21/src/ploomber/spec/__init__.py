from ploomber.spec.dagspec import DAGSpec

__all__ = ['DAGSpec']
