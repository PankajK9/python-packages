---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
---

<!-- #region slideshow={"slide_type": "slide"} -->
A markdown cell
<!-- #endregion -->

```python slideshow={"slide_type": ""}
1+1
```

<!-- #region cell_style="center" slideshow={"slide_type": "fragment"} -->
Markdown cell two
<!-- #endregion -->
