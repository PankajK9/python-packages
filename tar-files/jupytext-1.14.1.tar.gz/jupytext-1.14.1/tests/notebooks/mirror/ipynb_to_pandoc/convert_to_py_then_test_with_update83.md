---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
  nbformat: 4
  nbformat_minor: 2
---

::: {.cell .code}
``` python
%%time

print('asdf')
```
:::

::: {.cell .markdown}
Thanks for jupytext!
:::

::: {.cell .code}
``` python
```
:::
