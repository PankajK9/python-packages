# ---
# jupyter:
#   jupytext:
#     cell_markers: region,endregion
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# This is an unfrozen cell. Works as usual.
print("I'm a regular cell so I run and print!")

# region deletable=false editable=false run_control={"frozen": true}
# # This is an frozen cell
# print("I'm frozen so Im not executed :(")
# endregion
