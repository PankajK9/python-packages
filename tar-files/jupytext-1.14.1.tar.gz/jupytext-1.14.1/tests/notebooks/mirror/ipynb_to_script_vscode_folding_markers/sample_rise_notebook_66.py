# ---
# jupyter:
#   jupytext:
#     cell_markers: region,endregion
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# region [markdown] slideshow={"slide_type": "slide"}
# A markdown cell
# endregion

# region slideshow={"slide_type": ""}
1+1
# endregion

# region [markdown] cell_style="center" slideshow={"slide_type": "fragment"}
# Markdown cell two
# endregion
