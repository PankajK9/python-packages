# ---
# jupyter:
#   kernelspec:
#     display_name: R
#     language: R
#     name: ir
# ---

# This is a jupyter notebook that uses the IR kernel.

sum(1:10)

plot(cars)


