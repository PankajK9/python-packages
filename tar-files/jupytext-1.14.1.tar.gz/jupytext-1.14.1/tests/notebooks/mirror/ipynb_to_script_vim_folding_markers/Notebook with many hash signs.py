# ---
# jupyter:
#   jupytext:
#     cell_markers: '{{{,}}}'
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# ##################################################################
# This is a notebook that contains many hash signs.
# Hopefully its python representation is not recognized as a Sphinx Gallery script...
# ##################################################################

# {{{
some = 1
code = 2
some+code

##################################################################
# A comment
##################################################################
# Another comment
# }}}

# ##################################################################
# This is a notebook that contains many hash signs.
# Hopefully its python representation is not recognized as a Sphinx Gallery script...
# ##################################################################
