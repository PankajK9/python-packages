"""Jupytext's version number"""

__version__ = "1.14.1"
